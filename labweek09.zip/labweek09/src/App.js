import React from 'react';
import './App.css';
import logo from './logo.svg';  // Ensure the default React logo is being used.

function App() {
    return (
        <div className="App">
            <img src={logo} className="App-logo" alt="React logo" />
            <h1 className="App-title">Welcome to Fullstack Development - I</h1>
            <p className="App-subtitle">React JS Programming Week09 Lab exercise</p>
            <p className="App-text">101432361</p>
            <p className="App-text">Nikola Varicak</p>
            <p className="App-text">George Brown College, Toronto</p>
        </div>
    );
}

export default App;
